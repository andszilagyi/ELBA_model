int logInit(int individual, int sum, const char *id);
void logDone();

int logGlobalParams(int avgDays, const char* version, int seed, int individualNum, int foodBerryNum, int foodMeatNum, int foodLeader, int groupCount, int groupSize, int transientYears, int meatSizeLow, int meatSizeHigh);
int logGlobal(int dayStep, int individualNum, int energySum, float energyAvg, double traitCommunicationSum, float traitCommunicationAvg, int spareFood, int avgFoodDistance, int avgFoodAmount, int meatsEaten, int berriesEaten, int newChildren, int deadByNatural, int deadByHunger, int deadByPredation, float avgAge, double minCommunication, double maxCommunication, float avgTeamsize, int adultsNum, int childrenNum, float avgAgeChildren, int oldest, int youngAdultsLeft, float groupFillPercent, float groupFillMax, float relativeFillPercent, float relativeFillMax, int resting, int scouting, int fetching, int berrySum, int berryCnt, int meatSum, int meatCnt, int childrenStarving, int foodNeeded, int actualEatenWork, int actualEatenHome, int actualEatenShared, int actualEatenKids, int deadByMaxAge, int stepsTaken, int foodBroughtin, int movingAdults, int childrenDeadByHunger, double freeTime);

int logIndividualStart(int dayStep);
int logIndividualEnd();
int logIndividual(int energy, double communication);

int logTraitHistogram(int day, int *traitGroups, int groupCount);
int logAgeHistogram(int day, int *ageGroups, int groupCount);

int logTblStats(int amount, int distance, int people);
int logSaveTblstats();
