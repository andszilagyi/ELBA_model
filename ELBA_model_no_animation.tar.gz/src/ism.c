#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "log.h"
#include "rand.h"
#include "gasdev.h"
#include "version.h"

int loggingIndividual = 0;
int loggingSum = 1;
int debug = 0;

#define ANI_DAY_FROM (SIM_START_DAY + 100000*365-1)
#define ANI_DAY_TO (SIM_START_DAY + 100000*365+49)

// --- parameters ---
int RndSeed = 1;

int FoodsBerryNum = 1500; // number of berry type food sources
int FoodsMeatNum = 100; // number of meat type food sources
int AdultsNum = 100; // number of adults
float MutationRate = 0.01;
int TransientYears = 10000;

int MeatSizeLow = 60000;
int MeatSizeHigh = 90000;

#define INFO_GROUP_MODE (1)
#define MUT_LIMIT (1.0)

#define DAYS_NUM (365*200000) // how many days
#define AVG_DAYS (365) // statistics average range in days
#define MEAT_START_DAY (365*20000) // meat start day
#define FOOD_BERRY_REFILL_DECREASE (1)
#define FOOD_BERRY_SURVIVING_PERCENT (10) // percent of bushes
#define FOOD_BERRY_REMAINING_PERCENT (10) // percent of berries on a bush
#define FOOD_MEAT_FILL_PERCENT (100) // relative to berry drop
#define INDIVIDUALS_NUM (1000) // number of individuals
#define COMMUNICATION_START_MAX (0.01)
#define FOOD_TIMER_MAX (6) // in days
#define FIELD_SIZE (120) // 0.25 km / field, 30 x 30 km
#define SPEED_DEFAULT (10) // fields / hour, 2.5 km/h
#define DAYLIGHT_HOURS (12)
#define ENERGY_MAX (2000) // per individual
#define FOOD_AMOUNT_TOOSMALL (300) // too little for a group to form
#define INDIVIDUAL_LOAD_MAX (1000) // in food/energy
#define FOOD_BERRY_LOAD_MAX (800)
#define FOOD_EATEN_MAX (200) // per meal
#define FOOD_IDLE (100) // fixed daily requirement
#define LOADSKIP_SCALE (10) // 0 load 10 pixel/hour, 10 load 4 pixel/hour
#define FOOD_BERRY_DECREASE_PERCENT (99)
#define AGE_ADULT (365*10)
#define NATURAL_DEATH (10000) // probability
#define PREDATION_DEATH (2222) // probability
#define CHILD_ENERGY_DEFAULT (600)
#define CHILD_BIRTH_MONTHS (14)
#define COMMUNICATION_COST_PERCENT (10) // to trait max
#define AGE_MAX (365*40)
#define CHILD_MOTIVATION_VALUE (10) // additional bravery when all children are starving
#define FOODS_BERRY_MOVEMENT_POSSIBILITY (50000)
#define FOOD_MEAT_BUTCHERED_STEPS (3) // how long the meats stay accessible after butchering

#define MEAT_TOTAL_ENERGY (7500000)

#define FORCE_RECRUIT (0) // enable:1 disable:0 TODO remove this
#define FORCE_RECRUIT_START (4) // number from Eors

// --- calculated values ---
#define ENERGY_DEFAULT (ENERGY_MAX)
#define FOOD_LEADER_MAX (FOOD_EATEN_MAX + (FOOD_EATEN_MAX / 2)) // (150%)
#define FOOD_BERRY_AMOUNT_MAX (FOOD_AMOUNT_TOOSMALL)
#define GROUP_SIZE (INDIVIDUALS_NUM) // number of individuals per group
#define SIM_START_DAY (AGE_ADULT)
#define CHILD_ENERGY_MAX (ENERGY_MAX / 2)
#define FOOD_CHILD_IDLE (FOOD_IDLE / 2)
#define COMMUNICATION_COST_CHILD_PERCENT (COMMUNICATION_COST_PERCENT / 2)
#define FOODS_BERRY_REMAINING_AMOUNT ((FOOD_BERRY_AMOUNT_MAX * FOOD_BERRY_REMAINING_PERCENT) / 100)
#define CHILD_BIRTH_ENERGY ((CHILD_BIRTH_SPARE * 365 * CHILD_BIRTH_MONTHS) / 12)
#define CHILD_BIRTH_SPARE ((FOOD_CHILD_IDLE * 3) / 2)

// parameter limits
#define FOODS_NUM_LIMIT (10000)
#define GROUP_SIZE_LIMIT (INDIVIDUALS_NUM+1)
#define MUTATION_RATE_LIMIT (1)

// --- auxiliary constants ---
#define FIELD_FREE (-1)
#define INGROUP_NONE (-1)
#define STEPS_PER_DAY (DAYLIGHT_HOURS * SPEED_DEFAULT)
#define GROUP_NUM_MAX (INDIVIDUALS_NUM + 1) // number of groups
#define GROUP_NUM_MAX_LIMIT (GROUP_NUM_MAX)

enum STATUS_LIST
{
  STATUS_FREE=0,
  STATUS_IDLE,            // idle
  STATUS_CHILD,           // not yet grown up
  STATUS_SEARCHING,       // look for food using correlated random walk
  STATUS_FOUND,           // return to camp with info
  STATUS_GIVINGUP,        // return to camp before dusk
  STATUS_STORYTIME,       // talk about food
  STATUS_FETCHING,        // return to food
  STATUS_RETURNING_BERRY, // return with food to camp (berry)
  STATUS_RETURNING_MEAT,  // return with food to camp (meat)
  STATUS_RETURNED,        // wait for sharing food
  STATUS_WANDERING,       // look for food to return nearby using random walk
};

enum FOOD_TYPES
{
    FOOD_BERRY=0,
    FOOD_MEAT,
};

// --- data structures ---

struct INDIVIDUAL
{
    int status;
    int energy;
    int inGroup;
    int foodLoad;
    int foodShare;
    int foodEaten;
    int birthDay;
    double traitCommunication;
    int childBirthEnergy;
};

struct INDIVIDUAL individuals[INDIVIDUALS_NUM];

struct GROUP
{
    int status;
    int size;
    int members[GROUP_SIZE_LIMIT];
    int loads[GROUP_SIZE_LIMIT];
    int groupX;
    int groupY;
    int facing;
    int foodX;
    int foodY;
    int foodAmount; // discovered
    int foodDanger; // percent
    int maxLoad; // upon returning
    int loadSkip;
};

struct GROUP groups[GROUP_NUM_MAX_LIMIT];

struct FOOD
{
    int status;
    int type;
    int x;
    int y;
    int timer;  // counts down to zero
    int amount; // energy
    int danger; // calculated from distance
    int isButchered; // meat is butchered
    int isSurviving; // berry bush is survivor
    int butcheredStep; // when it was butchered
};

struct FOOD foods[FOODS_NUM_LIMIT];

int day = SIM_START_DAY;
int step = 0; // 8am to 8pm: 12 hours, 12*SPEED_DEFAULT steps
int campX = FIELD_SIZE/2;
int campY = FIELD_SIZE/2;
int spareFood = 0;

int foodBerryDecreaseTimer = 365 * 40; // overwritten in init
int foodBerryRefillDaily = FOOD_AMOUNT_TOOSMALL; // decreased to 0 during transition phase

int amountMeats = 0;
int amountBerries = 0;
int diffMeats = 0;
int diffBerries = 0;
int newChildren = 0;
int adultsPerDay = 0;
int childrenPerDay = 0;
int childrenDone = 0;
int deadByNatural = 0;
int deadByHunger = 0;
int deadByPredation = 0;
int deadByMaxAge = 0;
int youngAdultsLeft = 0;
int groupFillPercentSum = 0;
int groupFillPercentMax = -1;
int groupFillRelativeSum = 0;
int groupFillRelativeMax = -1;
int groupFillCnt = 0;
int meatAddDays = 1;
int motivationPercent = 0;
int childrenStarving = 0;
int actualEatenWorking = 0;
int actualEatenKids = 0;
int actualEatenHome = 0;
int actualEatenShared = 0;
int stepsTakenAll = 0;
int foodBroughtinAll = 0;
int movingAdults = 0;
int childrenDeadByHunger = 0;
int freeTime = 0;
int freeTimeCnt = 0;

int field[FIELD_SIZE][FIELD_SIZE];

// --- auxiliary functions ---


const char *statusToString(int status)
{
    switch(status)
    {
        case STATUS_FREE: return("free");
        case STATUS_IDLE: return("idle");
        case STATUS_CHILD: return("child");
        case STATUS_SEARCHING: return("searching");
        case STATUS_FOUND: return("found");
        case STATUS_GIVINGUP: return("givingup");
        case STATUS_STORYTIME: return("storytime");
        case STATUS_FETCHING: return("fetching");
        case STATUS_RETURNING_BERRY: return("returningberry");
        case STATUS_RETURNING_MEAT: return("returningmeat");
        case STATUS_RETURNED: return("returned");
        case STATUS_WANDERING: return("wandering");
    }
    return("N/A");
}

int distance(int x1, int y1, int x2, int y2)
{
    return(abs(x1-x2) + abs(y1 - y2));
}

int bound(int v, int low, int high)
{
    if(v < low) return(low);
    if(v > high) return(high);
    return(v);
}

int maxInt(int a, int b)
{
    if(a < b) return(b);
    return(a);
}

int minInt(int a, int b)
{
    if(a > b) return(b);
    return(a);
}

int absInt(int v)
{
    if(v < 0) return(-v);
    return(v);
}

void error(const char* errs)
{
    fprintf(stderr, "error: %s\n", errs);
    printf("error: %s\n", errs);
    exit(1);
}

// --------------------------------------------------------------------------------

int correlatedRandomWalk(int facing)
{
    int r;
    if(facing < 0) return(randl(4));
    r = randl(100);
    if(r < 93) return(facing);
    if(r < 96) return((facing + 1) % 4);
    return((facing + 3) % 4);
}

int randomWalk()
{
    return(randl(4));
}

struct CommsTable
{
    int id;
    int result;
    double value;
};

int compareCommsTableResult(const void *v1, const void *v2)
{
    struct CommsTable *a = (struct CommsTable*)v1;
    struct CommsTable *b = (struct CommsTable*)v2;
    return(b->result - a->result);
}

int compareCommsTableValue(const void *v1, const void *v2)
{
    struct CommsTable *a = (struct CommsTable*)v1;
    struct CommsTable *b = (struct CommsTable*)v2;
    if(a->value == b->value) return(0);
    if(a->value < b->value) return(1);
    return(-1);
}

void qmix(struct CommsTable *tbl, int len)
{
    struct CommsTable temp;
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < len; j++)
        {
            int r = randl(len);
            if(r == j) continue;
            memcpy(&temp, tbl + j, sizeof(temp));
            memcpy(tbl + j, tbl + r, sizeof(temp));
            memcpy(tbl + r, &temp, sizeof(temp));
        }
}

int individualAlloc()
{
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status == STATUS_FREE)
        {
            individuals[t].status = STATUS_IDLE;
            individuals[t].energy = randl(ENERGY_DEFAULT / 2) + (ENERGY_DEFAULT / 2);
            individuals[t].traitCommunication = randd() * COMMUNICATION_START_MAX;
            individuals[t].inGroup = INGROUP_NONE;
            individuals[t].birthDay = day;
            individuals[t].childBirthEnergy = randl(CHILD_BIRTH_ENERGY);
            return(t);
        }
    return(-1);
}

void groupFree(int id);

void individualFree(int id)
{
    if((id < 0) || (id >= INDIVIDUALS_NUM)) error("individual id out of bounds");
    individuals[id].status = STATUS_FREE;
    for(int g = 0; g < GROUP_NUM_MAX; g++)
    {
        int delFlag = 0;
        if(groups[g].members[0] == id)
        {
            groups[g].members[0] = INGROUP_NONE;
            if(groups[g].status == STATUS_FETCHING)
                groups[g].status = STATUS_WANDERING;
            delFlag = 1;
        }
        for(int m = 1; m < groups[g].size; m++)
            if(groups[g].members[m] == id)
            {
                groups[g].members[m] = INGROUP_NONE;
                delFlag = 1;
            }
        if(delFlag == 1)
        {
            int c;
            for(c = 0; c < groups[g].size; c++)
                if(groups[g].members[c] != INGROUP_NONE)
                    break;
            if(c == groups[g].size)
                groupFree(g);
        }
    }
    individuals[id].inGroup = INGROUP_NONE;
}

int individualCount()
{
    int sum = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status != STATUS_FREE)
            sum++;
    return(sum);
}

int groupAlloc(int leader)
{
    for(int t = 0; t < GROUP_NUM_MAX; t++)
        if(groups[t].status == STATUS_FREE)
        {
            groups[t].status = STATUS_SEARCHING;
            groups[t].size = 1;
            groups[t].members[0] = leader;
            groups[t].groupX = campX;
            groups[t].groupY = campY;
            groups[t].facing = -1;
            groups[t].maxLoad = 0;
            individuals[leader].inGroup = t;
            individuals[leader].foodLoad = 0;
            return(t);
        }
    return(INGROUP_NONE);
}

int groupAddMember(int groupId, int member)
{
    if(groups[groupId].size == GROUP_NUM_MAX) return(INGROUP_NONE);
    groups[groupId].members[groups[groupId].size++] = member;
    individuals[member].inGroup = groupId;
    individuals[member].foodLoad = 0;
    return(groupId);
}

void groupFree(int id)
{
    if((id < 0) || (id >= GROUP_NUM_MAX)) error("group id out of bounds");
    for(int t = 0; t < groups[id].size; t++)
    {
        if(groups[id].members[t] == INGROUP_NONE) continue;
        individuals[groups[id].members[t]].inGroup = INGROUP_NONE;
        if(individuals[groups[id].members[t]].status != STATUS_FREE)
            individuals[groups[id].members[t]].status = STATUS_IDLE;
    }
    groups[id].status = STATUS_FREE;
}

int foodAlloc(void)
{
    for(int t = 0; t < FOODS_NUM_LIMIT; t++)
        if(foods[t].status == STATUS_FREE)
            return(t);
    return(-1);
}

void foodFree(int id)
{
    if((id < 0) || (id >= FOODS_NUM_LIMIT)) error("food id out of bounds");
    foods[id].status = STATUS_FREE;
}

int calcFoodBerryRefillDecreaseTime()
{
    return((TransientYears * 365) / FOOD_BERRY_AMOUNT_MAX);
}

int numberOfPeople()
{
    int sum = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status != STATUS_FREE)
            sum++;
    return(sum);
}

int numberOfAdults()
{
    int sum = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if((individuals[t].status != STATUS_FREE) && (individuals[t].status != STATUS_CHILD))
            sum++;
    return(sum);
}

void census(int *total, int *adults, int *children, int *oldest)
{
    *total = 0;
    *adults = 0;
    *children = 0;
    *oldest = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status != STATUS_FREE)
        {
            *oldest = maxInt(*oldest, day - individuals[t].birthDay);
            if(individuals[t].status == STATUS_CHILD)
                (*children)++;
            else
                (*adults)++;
        }
    *total = (*adults) + (*children);
}

int sumOfEnergy()
{
    int sum = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status != STATUS_FREE)
            sum += individuals[t].energy;
    return(sum);
}

void sumOfAge(int *adults, int *children)
{
    *adults = 0;
    *children = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status != STATUS_FREE)
        {
            if(individuals[t].status != STATUS_CHILD)
                (*adults) += day - individuals[t].birthDay;
            else
                (*children) += day - individuals[t].birthDay;
        }
}

void sumOfCommunication(double *sum, double *min, double *max)
{
    *sum = 0.0;
    *min = 1.0;
    *max = 0.0;
    int cg[11] = {};
    int ag[AGE_MAX / (365 * 5)] = {};
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status != STATUS_FREE)
        {
            double com = individuals[t].traitCommunication;
            *sum += com;
            if(*min > com) *min = com;
            if(*max < com) *max = com;
            cg[(int)round(com * 10)]++;
            int age = (day - individuals[t].birthDay) / (365 * 5);
            if(age < (AGE_MAX / (365 * 5))) ag[age]++;
        }
    if((day % 365) == 0)
    {
        logTraitHistogram(day, cg, sizeof(cg)/sizeof(int));
        logAgeHistogram(day, ag, sizeof(ag)/sizeof(int));
    }
}

float averageGroupsize()
{
    int tc = 0, ts = 0;
    for(int t = 0; t < GROUP_NUM_MAX; t++)
        if(groups[t].status == STATUS_FETCHING)
        {
            tc++;
            ts += groups[t].size;
        }
    if(tc == 0) return(-1.0);
    return(((float)ts) / ((float)tc));
}

void updateActivityStats(int *statResting, int *statScouting, int *statFetching)
{
  *statResting = 0;
  *statScouting = 0;
  *statFetching = 0;
  for(int t = 0; t < INDIVIDUALS_NUM; t++)
  {
      switch(individuals[t].status)
      {
          case STATUS_FREE:
          case STATUS_CHILD:
              break;
          default:
              if(individuals[t].inGroup == INGROUP_NONE)
              {
                  (*statResting)++;
              } else
              {
                  switch(groups[individuals[t].inGroup].status)
                  {
                      case STATUS_SEARCHING: (*statScouting)++; break;
                      case STATUS_FETCHING: (*statFetching)++; break;
                      case STATUS_WANDERING: (*statScouting)++; break;
                      default: error("bug-status");
                          //printf("bug: %d %d", groups[individuals[t].inGroup].status, groups[individuals[t].inGroup].members[0]);
                  }
              }
      }
  }
  if((*statResting + *statScouting + *statFetching) > AdultsNum) error("too many adults?");
}

int calcDanger(int distance, int type)
{
    if(type != FOOD_MEAT) return(0);
    // FIELD_SIZE / 2 -> 100%
    // 0 -> 0%
    int prob = (distance * 100) / (FIELD_SIZE / 2);
    if(prob < 0) return(0);
    return(prob);
}

int rollMeatAmount()
{
    if(MeatSizeHigh == MeatSizeLow) return(MeatSizeLow);
    return(randl(MeatSizeHigh - MeatSizeLow) + MeatSizeLow);
}

void dropFood(int id, int type)
{
    int x, y;
    int tryCnt;
    if(id < 0)
        id = foodAlloc();
    if(id < 0)
        error("Ran out of food slots!");
    foods[id].type = type;
    foods[id].timer = randl(FOOD_TIMER_MAX/2) + (FOOD_TIMER_MAX/2);
    foods[id].status = STATUS_IDLE;
    if(type == FOOD_MEAT)
    {
        if(day < MEAT_START_DAY)
            foods[id].amount = 0;
        else
            foods[id].amount = rollMeatAmount();
    } else
    {
        foods[id].amount = FOOD_BERRY_AMOUNT_MAX;
        foods[id].isSurviving = (FOOD_BERRY_SURVIVING_PERCENT > randl(100));
    }
    tryCnt = 0;
    do
    {
        tryCnt++;
        x = randl(FIELD_SIZE);
        y = randl(FIELD_SIZE);
        if(tryCnt >= FIELD_SIZE*FIELD_SIZE*FIELD_SIZE)
        {
            error("can't place additional food source");
        }
    }while(((x == campX) && (y == campY)) || (field[y][x] != FIELD_FREE) || (distance(campX, campY, x, y) >= (FIELD_SIZE/2)));
    field[y][x] = id;
    foods[id].danger = calcDanger(distance(x, y, campX, campY), type);
    foods[id].x = x;
    foods[id].y = y;
    foods[id].isButchered = 0;
}

void updateFoodStatsBegin()
{
    int sumMeats = 0;
    int sumBerries = 0;
    int numMeats = 0;
    int numBerries = 0;
    for(int t = 0; t < (FoodsMeatNum + FoodsBerryNum); t++)
    {
        if(foods[t].status == STATUS_FREE) continue;
        switch(foods[t].type)
        {
            case FOOD_MEAT:
                sumMeats += foods[t].amount;
                numMeats++;
                if(t >= FoodsMeatNum) error("food meat id error");
                break;
            case FOOD_BERRY:
                sumBerries += foods[t].amount;
                numBerries++;
                if(t < FoodsMeatNum) error("food berry id error");
                break;
        }
    }
    diffMeats = 0;
    diffBerries = 0;
    amountMeats = sumMeats;
    amountBerries = sumBerries;
    //printf("step0 %d : %d = %d + %d ( %d %d ) %d %d\n", day / 365, amountBerries + amountMeats, amountBerries, amountMeats, numBerries, numMeats, diffMeats, diffBerries);

}

void updateFoodStatsEnd()
{
    int sumMeats = 0;
    int sumBerries = 0;
    int numMeats = 0;
    int numBerries = 0;
    for(int t = 0; t < (FoodsMeatNum + FoodsBerryNum); t++)
    {
        if(foods[t].status == STATUS_FREE) continue;
        switch(foods[t].type)
        {
            case FOOD_MEAT:
                sumMeats += foods[t].amount;
                numMeats++;
                break;
            case FOOD_BERRY:
                sumBerries += foods[t].amount;
                numBerries++;
                break;
        }
    }
    diffMeats = amountMeats - sumMeats;
    diffBerries = amountBerries - sumBerries;
    amountMeats = sumMeats;
    amountBerries = sumBerries;
    //printf("step1 %d : %d = %d + %d ( %d %d ) %d %d\n", day / 365, amountBerries + amountMeats, amountBerries, amountMeats, numBerries, numMeats, diffMeats, diffBerries);
}

void updateFood()
{
    for(int t = 0; t < FoodsMeatNum; t++)
    {
        if((foods[t].status == STATUS_FREE) && (day >= (MEAT_START_DAY + meatAddDays * t)))
            dropFood(t, FOOD_MEAT);
        if(foods[t].status == STATUS_FREE) continue;
        if(foods[t].isButchered)
            foods[t].amount = 0;
        if(--foods[t].timer <= 0)
        {
            // respawn food
            field[foods[t].y][foods[t].x] = FIELD_FREE;
            dropFood(t, FOOD_MEAT);
        }
    }
    for(int t = FoodsMeatNum; t < (FoodsMeatNum + FoodsBerryNum); t++)
    {
        if(foods[t].status == STATUS_FREE) continue;
        if(randl(FOODS_BERRY_MOVEMENT_POSSIBILITY) == 0)
        {
            for(int tryCnt = 0, x, y; tryCnt < (FIELD_SIZE * FIELD_SIZE * FIELD_SIZE); tryCnt++)
            {
                tryCnt++;
                x = randl(FIELD_SIZE);
                y = randl(FIELD_SIZE);
                if(((x == campX) && (y == campY)) || (field[y][x] != FIELD_FREE) || (distance(campX, campY, x, y) >= (FIELD_SIZE/2)))
                    continue;
                field[foods[t].y][foods[t].x] = FIELD_FREE;
                field[y][x] = t;
                foods[t].danger = calcDanger(distance(x, y, campX, campY), foods[t].type);
                foods[t].x = x;
                foods[t].y = y;
                foods[t].isButchered = 0;
                break;
            }
        }
        if((foodBerryRefillDaily == 0) && (foods[t].amount <= 0) && (!foods[t].isSurviving))
        {
            field[foods[t].y][foods[t].x] = FIELD_FREE;
            foodFree(t);
        }else
        {
            foods[t].amount = (foods[t].amount * FOOD_BERRY_DECREASE_PERCENT) / 100;
            if(foods[t].isSurviving && (foodBerryRefillDaily < FOODS_BERRY_REMAINING_AMOUNT))
            {
                foods[t].amount += FOODS_BERRY_REMAINING_AMOUNT;
                if(foods[t].amount > FOODS_BERRY_REMAINING_AMOUNT) foods[t].amount = FOODS_BERRY_REMAINING_AMOUNT;
            } else
            {
                foods[t].amount += foodBerryRefillDaily;
                if(foods[t].amount > FOOD_BERRY_AMOUNT_MAX) foods[t].amount = FOOD_BERRY_AMOUNT_MAX;
            }
        }
    }
    if((day >= MEAT_START_DAY) && (day <= (MEAT_START_DAY + (TransientYears * 365) + calcFoodBerryRefillDecreaseTime() + 1)) && (--foodBerryDecreaseTimer <= 0))
    {
        foodBerryDecreaseTimer = calcFoodBerryRefillDecreaseTime();
        struct CommsTable tbl[FoodsBerryNum];
        int tblCnt = 0;
        foodBerryRefillDaily -= FOOD_BERRY_REFILL_DECREASE;
        if(foodBerryRefillDaily < 0) foodBerryRefillDaily = 0;
        for(int t = FoodsMeatNum; t < (FoodsMeatNum + FoodsBerryNum); t++)
            if((foods[t].status != STATUS_FREE) && (!foods[t].isSurviving))
                tbl[tblCnt++].id = t;
        if(tblCnt > 0)
        {
            qmix(tbl, tblCnt);
            for(int t = 0; (t < (FoodsBerryNum / FOOD_BERRY_AMOUNT_MAX)) && (t < tblCnt); t++)
            {
                int id = tbl[t].id;
                field[foods[id].y][foods[id].x] = FIELD_FREE;
                foodFree(id);
            }
        }
    }
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        individuals[t].foodEaten = 0;
}

void init(void)
{
    for(int y = 0; y < FIELD_SIZE; y++)
        for(int x = 0; x < FIELD_SIZE; x++)
            field[y][x] = FIELD_FREE;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        individuals[t].status = STATUS_FREE;
    for(int t = 0; t < GROUP_NUM_MAX; t++)
        groups[t].status = STATUS_FREE;
    for(int t = 0; t < AdultsNum; t++)
    {
        int gid;
        int id = individualAlloc();
        if(id < 0)
            error("Out of individual slots!");
        if((gid = groupAlloc(id)) < 0)
            error("Out of group slots!");
    }
    meatAddDays = (((foodBerryRefillDaily * calcFoodBerryRefillDecreaseTime()) * FOOD_MEAT_FILL_PERCENT) / 100) / FoodsMeatNum;
    foodBerryDecreaseTimer = calcFoodBerryRefillDecreaseTime();
    //printf("%d %d %d\n", meatAddDays, meatAddDays * FoodsMeatNum * 2 / 365, (foodBerryRefillDaily * calcFoodBerryRefillDecreaseTime()) / 365);
    for(int t = FoodsMeatNum; t < (FoodsMeatNum + FoodsBerryNum); t++)
        dropFood(t, FOOD_BERRY);
}

void groupStepMembers(int groupId)
{
    // decrease energy levels for each step
    switch(groups[groupId].status)
    {
        case STATUS_FREE:
        case STATUS_STORYTIME:
        case STATUS_IDLE:
        case STATUS_RETURNED:
            break;
        case STATUS_FETCHING:
        case STATUS_FOUND:
        case STATUS_GIVINGUP:
        case STATUS_RETURNING_BERRY:
        case STATUS_RETURNING_MEAT:
        case STATUS_SEARCHING:
        case STATUS_WANDERING:
            if((step % 2) == 0)
                for(int t = 0; t < groups[groupId].size; t++)
                {
                    int memberId = groups[groupId].members[t];
                    if(memberId == INGROUP_NONE) continue;
                    individuals[memberId].energy--;
                    if(individuals[memberId].energy <= 0)
                    {
                        individuals[memberId].foodLoad = 0;
                        individuals[memberId].energy = 0;
                        individualFree(memberId);
                        deadByHunger++;
                    }
                }
            break;
    }
}

void updateStepStats(int groupId)
{
    for(int t = 0; t < groups[groupId].size; t++)
    {
        int memberId = groups[groupId].members[t];
        if(memberId == INGROUP_NONE) continue;
        stepsTakenAll += (step + 1);
        foodBroughtinAll += individuals[memberId].foodLoad;
        movingAdults++;
        freeTime += STEPS_PER_DAY - step;
        freeTimeCnt++;
    }
}

int calcLoadSkip(int load)
{
    if(load > INDIVIDUAL_LOAD_MAX) error("overload detected!");
    return(load / 400);
}

int calcSlowdown(int load)
{
    return(10 + calcLoadSkip(load) * 2);
}

int calcMaxLoadWithTime(int distance, int remainingTime)
{
    int maxLoad = 2000 - (2000 * distance / remainingTime);
    return(bound(maxLoad, 0, INDIVIDUAL_LOAD_MAX));
}

int calcBravery(int energy)
{
    int bravery = (100 * (ENERGY_MAX - energy)) / ENERGY_MAX;
    bravery = bound(bravery + ((CHILD_MOTIVATION_VALUE * motivationPercent) / 100), 0, 100);
    return(bravery);
}

int isTimeToReturn(int groupId)
{
    int leaderId = groups[groupId].members[0];
    if(leaderId == INGROUP_NONE) return(!0);
    if(((distance(groups[groupId].groupX, groups[groupId].groupY, campX, campY) * calcSlowdown(individuals[leaderId].foodLoad)) / 10) >= ((STEPS_PER_DAY-10) - step)) return(!0);
    return(0);
}

int distanceGroups1(int distance)
{
    if(distance == 0) return(0);
    if(distance <= 18) return(1); // 4.5 km
    if(distance <= 36) return(2); // 9 km
    if(distance <= 54) return(3); // 13.5 km
    return(4);
}

int distanceGroups2(int distance)
{
    if(distance == 0) return(0);
    if(distance <= 20) return(1); // 5 km
    if(distance <= 40) return(2); // 10 km
    if(distance <= 60) return(3); // 15 km
    return(4);
}

int distanceGroups3(int distance)
{
    if(distance == 0) return(0);
    if(distance <= 40) return(1); // 10 km
    if(distance <= 47) return(2); // 11.75 km
    if(distance <= 54) return(3); // 13.5 km
    return(4);
}

int distanceGroups4a(int distance)
{
    if(distance == 0) return(0);
    if(distance <= 40) return(1); // 10 km
    if(distance <= 60) return(2); // 15 km
    return(3);
}

int distanceGroups4b(int distance)
{
    if(distance == 0) return(0);
    if(distance <= 40) return(1); // 10 km
    if(distance <= 54) return(2); // 13.5 km
    return(3);
}

int distanceGroups(int distance)
{
  return(distanceGroups4a(distance));
}

int foodAmountGroups(int amount)
{
    if(amount == 0) return(0);
    if(amount < 10000) return(1);
    if(amount < 20000) return(2);
    if(amount < 30000) return(3);
    if(amount < 40000) return(4);
    if(amount < 50000) return(5);
    if(amount < 60000) return(6);
    if(amount < 70000) return(7);
    if(amount < 80000) return(8);
    if(amount < 90000) return(9);
    return(10);
}

const int GroupsizeTable[11][5] = // [amount][distance]
{ // == 0 <= 10 <= 15 >15 (km)
    {0,   0,   0,   0,   0},
    {0,  10,  30,   0,   0}, // < 10 (x1000)
    {0,  10,  30,   0,   0}, // < 20
    {0,  10,  30,   0,   0}, // < 30
    {0,  10,  30,   0,   0}, // < 40
    {0,  20,  50,   0,   0}, // < 50
    {0,  20,  50,   0,   0}, // < 60
    {0,  20,  50,   0,   0}, // < 70
    {0,  30,  50,   0,   0}, // < 80
    {0,  40,  50,   0,   0}, // < 90
    {0,  50,  50,   0,   0}, // >= 90
};

void communicate(int groupId)
{
    struct CommsTable c[INDIVIDUALS_NUM];
    int needed = 0;
    int added = 0;
    int cnt = 0;
    int amount;
    int dist;

    if(day < MEAT_START_DAY) error("should be no group forming in the berry only phase");
    if(INFO_GROUP_MODE == 0)
    {
        dist = distance(groups[groupId].foodX, groups[groupId].foodY, campX, campY);
        groups[groupId].maxLoad = calcMaxLoadWithTime(dist, STEPS_PER_DAY - dist);
        needed = (groups[groupId].foodAmount / (groups[groupId].maxLoad + FOOD_EATEN_MAX)) - 1;
    } else
    {
        groups[groupId].maxLoad = -1;
        dist = distanceGroups(distance(groups[groupId].foodX, groups[groupId].foodY, campX, campY));
        amount = foodAmountGroups(groups[groupId].foodAmount);
        needed = GroupsizeTable[amount][dist];
    }
    if((groups[groupId].members[0] == INGROUP_NONE) ||
       (groups[groupId].foodDanger > calcBravery(individuals[groups[groupId].members[0]].energy)) ||
       (groups[groupId].maxLoad == 0))
    {
        groupFree(groupId);
        return;
    }
    double leaderComms = individuals[groups[groupId].members[0]].traitCommunication;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
    {
        if((individuals[t].status == STATUS_FREE) || (individuals[t].status == STATUS_CHILD) || (individuals[t].inGroup != INGROUP_NONE)) continue;
        int percivedDanger = fmin(fmax(groups[groupId].foodDanger + ((((randd() * 2.0) - 1.0) * (1 - (individuals[t].traitCommunication * leaderComms))) * 100.0), 0.0), 100.0);
        int bravery = calcBravery(individuals[t].energy);
        if(percivedDanger > bravery) continue;
        c[cnt].id = t;
        c[cnt].result = groups[groupId].foodDanger - percivedDanger + 100;
        c[cnt].value = individuals[t].traitCommunication;
        cnt++;
    }
    //qsort(c, cnt, sizeof(struct CommsTable), compareCommsTableResult);
    qmix(c, cnt);
    // dertermine the number of required individuals
    //printf("day=%d meat=%d pool=%d needed=%d\n", day, groups[groupId].foodAmount, cnt, needed);
    if(needed > 1)
    {
        if(needed > (GROUP_SIZE - 1)) needed = GROUP_SIZE - 1; // groups already have their leader
        for(int t = 0; (t < cnt) && (added < needed); t++)
        {
            if(c[t].value >= randd())
            //if(c[t].result >= randl(200))
            {
                groupAddMember(groupId, c[t].id);
                added++;
            }
        }
        int per = (added * 100) / needed;
        int rel = 0;
        if(cnt > 0) rel = (added * 100) / cnt;
        groupFillPercentSum += per;
        if(groupFillPercentMax < per) groupFillPercentMax = per;
        groupFillRelativeSum += rel;
        if(groupFillRelativeMax < rel) groupFillRelativeMax = rel;
        groupFillCnt++;
    }
    logTblStats(amount, dist, added);
    groups[groupId].status = STATUS_FETCHING;
}

double mutateTrait(double trait)
{
    return(fmin(fmax(trait + (gasdev_scaled(MutationRate)), 0.0), MUT_LIMIT));
}

int addNewChildWithParent(int parentId)
{
    for(int childId = 0; childId < INDIVIDUALS_NUM; childId++)
        if(individuals[childId].status == STATUS_FREE)
        {
            individuals[childId].status = STATUS_CHILD;
            individuals[childId].inGroup = INGROUP_NONE;
            individuals[childId].traitCommunication = mutateTrait(individuals[parentId].traitCommunication);
            individuals[childId].energy = CHILD_ENERGY_DEFAULT;
            individuals[childId].birthDay = day;
            //printf(" %d parent energy %d comms %lf\n", day, individuals[parentId].energy, individuals[parentId].traitCommunication);
            individuals[parentId].childBirthEnergy -= CHILD_BIRTH_ENERGY;
            newChildren++;
            return(!0);
        }
    return(0);
}

int rollPredation(int danger)
{
    return((randl(PREDATION_DEATH * 100)) < danger);
}

int foodAmount(int foodId)
{
  if((foodId < 0) || (foodId >= FOODS_NUM_LIMIT))
    return(0);
  switch(foods[foodId].type)
  {
    case FOOD_BERRY:
      return(foods[foodId].amount);
    case FOOD_MEAT:
      if((foods[foodId].isButchered == 1) && (step > (foods[foodId].butcheredStep + FOOD_MEAT_BUTCHERED_STEPS)))
        return(0);
      return(foods[foodId].amount);
  }
  return(0);
}

void butcherFood(int groupId, int foodId)
{
    int eaten;
    int packed;
    int maxLoad = 0;
    int food0 = foodAmount(foodId);
    if(foods[foodId].type == FOOD_MEAT)
    {
        if(foods[foodId].isButchered == 0)
        {
          foods[foodId].isButchered = 1;
          foods[foodId].butcheredStep = step;
        }
        if(food0 <= 0) error("can't butcher an empty source");
    }
    groups[groupId].maxLoad = calcMaxLoadWithTime(distance(campX, campY, foods[foodId].x, foods[foodId].y), (STEPS_PER_DAY-1) - step);
    if((foods[foodId].type == FOOD_BERRY) && (groups[groupId].maxLoad > FOOD_BERRY_LOAD_MAX))
        groups[groupId].maxLoad = FOOD_BERRY_LOAD_MAX;
    // eat locally based on members and food amount
    for(int t = 0; t < groups[groupId].size; t++)
    {
        int memberId = groups[groupId].members[t];
        if((memberId == INGROUP_NONE) || (individuals[memberId].foodEaten >= FOOD_EATEN_MAX)) continue; // no member or already full
        eaten = minInt(foods[foodId].amount, FOOD_EATEN_MAX);
        if((individuals[memberId].foodEaten + eaten) > FOOD_EATEN_MAX)
            eaten = FOOD_EATEN_MAX - individuals[groups[groupId].members[t]].foodEaten;
        individuals[memberId].energy += eaten;
        individuals[memberId].foodEaten += eaten;
        actualEatenWorking += eaten;
        if(individuals[memberId].energy > ENERGY_MAX) individuals[memberId].energy = ENERGY_MAX;
        foods[foodId].amount -= eaten;
        //if(foods[foodId].type == FOOD_MEAT) printf("member %d eats %d\n", t, eaten);
    }
    // pack based on maximal load and food amount
    for(int t = 0; t < groups[groupId].size; t++)
    {
        if(groups[groupId].members[t] == INGROUP_NONE) continue;
        packed = minInt((foods[foodId].amount / groups[groupId].size), groups[groupId].maxLoad - individuals[groups[groupId].members[t]].foodLoad);
        individuals[groups[groupId].members[t]].foodLoad += packed;
        if(packed > 0) foods[foodId].amount -= packed;
        if(individuals[groups[groupId].members[t]].foodLoad > groups[groupId].maxLoad) error("overload detected!");
        if(foods[foodId].type == FOOD_MEAT)
        {
        }
    }
    groups[groupId].loadSkip = calcLoadSkip(maxLoad);
    for(int t = 0; t < groups[groupId].size; t++)
    {
        int memberId = groups[groupId].members[t];
        if(memberId == INGROUP_NONE) continue;
        if(rollPredation(groups[groupId].foodDanger))
        {
            individuals[memberId].foodLoad = 0;
            individuals[memberId].energy = 0;
            individualFree(memberId);
            deadByPredation++;
        }
    }
}

void shareFood(int groupId)
{
    int pool = 0;
    int size = 0;
    for(int t = 0; t < groups[groupId].size; t++)
    {
        int memberId = groups[groupId].members[t];
        if((memberId != INGROUP_NONE) && (individuals[memberId].status != STATUS_FREE))
        {
            pool += individuals[memberId].foodLoad;
            individuals[memberId].foodLoad = 0;
            size++;
        }
    }
    if(size == 0) return;
    // groups eats first with leader eating (if size > 1) FOOD_LEADER_MAX, everybody else FOOD_EATEN_MAX, distribute the rest
    int foodLeader = (groups[groupId].size > 1) ? FOOD_LEADER_MAX : FOOD_EATEN_MAX;
    if(pool < (((size-1) * FOOD_EATEN_MAX) + foodLeader))
    {
        int share = pool / size;
        for(int t = 0; t < groups[groupId].size; t++)
        {
            int memberId = groups[groupId].members[t];
            if(memberId != INGROUP_NONE)
                if(individuals[memberId].status != STATUS_FREE)
                    individuals[memberId].foodShare += share;
        }
    } else
    {
        if(groups[groupId].members[0] != INGROUP_NONE)
            individuals[groups[groupId].members[0]].foodShare = foodLeader;
        for(int t = 1; t < groups[groupId].size; t++)
        {
            int memberId = groups[groupId].members[t];
            if(memberId == INGROUP_NONE) continue;
            if(individuals[memberId].status != STATUS_FREE)
                individuals[memberId].foodShare += FOOD_EATEN_MAX;
        }
        pool -= ((size-1) * FOOD_EATEN_MAX) + foodLeader;
        spareFood += pool;
   }
}

void getFoodStats(int *avgFoodDistance, int *avgFoodAmount, int *meatsEaten, int *berriesEaten, int *berrySum, int *berryCnt, int *meatSum, int *meatCnt, int *foodNeeded)
{
    int sd = 0;
    int sa = 0;
    int cnt = 0;
    *avgFoodDistance = 0;
    *avgFoodAmount = 0;
    *meatsEaten = 0;
    *berriesEaten = 0;
    *berrySum = 0;
    *berryCnt = 0;
    *meatSum = 0;
    *meatCnt = 0;
    *foodNeeded = 0;
    for(int t = 0; t < (FoodsMeatNum + FoodsBerryNum); t++)
    {
        if(foods[t].status == STATUS_FREE) continue;
        sd += distance(campX, campY, foods[t].x, foods[t].y);
        sa += foods[t].amount;
        cnt++;
        switch(foods[t].type)
        {
            case FOOD_MEAT:
                (*meatSum) += foods[t].amount;
                (*meatCnt)++;
                break;
            case FOOD_BERRY:
                (*berrySum) += foods[t].amount;
                (*berryCnt)++;
                break;
        }
    }
    if(cnt == 0) return;
    *avgFoodDistance = sd / cnt;
    *avgFoodAmount = sa / cnt;
    if(avgFoodAmount == 0) error("Bug: avgFoodAmount");
    *meatsEaten = diffMeats;
    *berriesEaten = diffBerries;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
    {
        if(individuals[t].status == STATUS_FREE) continue;
        if(individuals[t].status == STATUS_CHILD)
        {
            (*foodNeeded) += FOOD_CHILD_IDLE + individuals[t].traitCommunication * COMMUNICATION_COST_CHILD_PERCENT;
        } else
        {
            (*foodNeeded) += FOOD_IDLE * 3 + individuals[t].traitCommunication * COMMUNICATION_COST_PERCENT; // assumed daily walk
        }
    }
}

void stepDayBegin()
{
    // update food status
    updateFood();
    if(loggingSum)
        updateFoodStatsBegin();
    spareFood = 0;
    newChildren = 0;
    adultsPerDay = 0;
    childrenPerDay = 0;
    childrenDone = 0;
    deadByNatural = 0;
    deadByHunger = 0;
    deadByPredation = 0;
    deadByMaxAge = 0;
    youngAdultsLeft = 0;
    groupFillPercentSum = 0;
    groupFillPercentMax = 0;
    groupFillRelativeSum = 0;
    groupFillRelativeMax = 0;
    groupFillCnt = 0;
    actualEatenWorking = 0;
    actualEatenKids = 0;
    actualEatenHome = 0;
    actualEatenShared = 0;
    stepsTakenAll = 0;
    foodBroughtinAll = 0;
    movingAdults = 0;
    childrenDeadByHunger = 0;
    freeTime = 0;
    freeTimeCnt = 0;
    if(loggingSum)
        for(int t = 0; t < INDIVIDUALS_NUM; t++)
            if(individuals[t].status == STATUS_IDLE)
            {
                freeTime += STEPS_PER_DAY;
                freeTimeCnt++;
            }
}

void stepDayMovement()
{
    for(step = 0; step < STEPS_PER_DAY; step++)
    {
        for(int t = 0; t < GROUP_NUM_MAX; t++)
        {
            switch(groups[t].status)
            {
                case STATUS_SEARCHING:
                {
                    int newDir = correlatedRandomWalk(groups[t].facing);
                    int dx = 0, dy = 0;
                    switch(newDir)
                    {
                        case 0: dx = 0; dy = -1; break;
                        case 1: dx = 1; dy = 0; break;
                        case 2: dx = 0; dy = 1; break;
                        case 3: dx = -1; dy = 0; break;
                    }
                    groups[t].groupX = bound(groups[t].groupX + dx, 0, FIELD_SIZE-1);
                    groups[t].groupY = bound(groups[t].groupY + dy, 0, FIELD_SIZE-1);
                    groups[t].facing = newDir;
                    // check field for food, found if true
                    int foodId = field[groups[t].groupY][groups[t].groupX];
                    if((foodId != FIELD_FREE) && (foodAmount(foodId) > 0) && (foods[foodId].timer > 1))
                    {
                        if(foods[foodId].amount <= 0) error("empty foodsource should be ignored!");
                        if((foods[foodId].type == FOOD_BERRY) && (foods[foodId].amount > FOOD_BERRY_AMOUNT_MAX)) error("oversize berry detected");
                        groups[t].foodX = groups[t].groupX;
                        groups[t].foodY = groups[t].groupY;
                        groups[t].foodAmount = foods[foodId].amount;
                        groups[t].foodDanger = foods[foodId].danger;
                        groups[t].status = STATUS_FOUND;
                        if((groups[t].foodAmount <= FOOD_AMOUNT_TOOSMALL) || (foods[foodId].isButchered))
                        {
                            butcherFood(t, foodId);
                            if((foods[foodId].type == FOOD_BERRY) && (groups[t].maxLoad > FOOD_BERRY_LOAD_MAX)) error("berry maxload bug");
                            if((foods[foodId].type == FOOD_BERRY) && ((individuals[groups[t].members[0]].foodEaten < FOOD_EATEN_MAX) || (individuals[groups[t].members[0]].foodLoad < groups[t].maxLoad)))
                            {
                                groups[t].status = STATUS_SEARCHING; // still hungry or not fully loaded
                                //if((individuals[groups[t].members[0]].foodLoad < groups[t].maxLoad))
                                //    printf("should give up? %d: %d %d %d\n", t, distance(groups[t].groupX, groups[t].groupY, campX, campY), ((distance(groups[t].groupX, groups[t].groupY, campX, campY) * calcSlowdown(individuals[groups[t].members[0]].foodLoad)) / 10), (STEPS_PER_DAY-1) - step);
                            } else if((foods[foodId].type == FOOD_MEAT) && (individuals[groups[t].members[0]].foodLoad == 0))
                            {
                                groups[t].status = STATUS_SEARCHING; // still hungry and not loaded
                            } else
                            {
                                groups[t].status = (foods[foodId].type == FOOD_BERRY) ? STATUS_RETURNING_BERRY : STATUS_RETURNING_MEAT;
                            }
                        }
                    }
                    // check return time based on distance
                    if((groups[t].status == STATUS_SEARCHING) && isTimeToReturn(t))
                    {
                        if((groups[t].members[0] != INGROUP_NONE) && (individuals[groups[t].members[0]].foodLoad > 0))
                            groups[t].status = STATUS_RETURNING_BERRY;
                        else
                            groups[t].status = STATUS_GIVINGUP;
                    }
                    // decrease energy for all members
                    groupStepMembers(t);
                    break;
                }
                case STATUS_FOUND:
                {
                    // return to camp
                    if(groups[t].groupX > campX)
                        groups[t].groupX--;
                    else if(groups[t].groupX < campX)
                        groups[t].groupX++;
                    else if(groups[t].groupY > campY)
                        groups[t].groupY--;
                    else if(groups[t].groupY < campY)
                        groups[t].groupY++;
                    else
                    {
                        updateStepStats(t);
                        groups[t].status = STATUS_STORYTIME;
                    }
                    // decrease energy for all members
                    groupStepMembers(t);
                    break;
                }
                case STATUS_FETCHING:
                {
                    // return to food
                    if(groups[t].groupY > groups[t].foodY)
                        groups[t].groupY--;
                    else if(groups[t].groupY < groups[t].foodY)
                        groups[t].groupY++;
                    else if(groups[t].groupX > groups[t].foodX)
                        groups[t].groupX--;
                    else if(groups[t].groupX < groups[t].foodX)
                        groups[t].groupX++;
                    else if(field[groups[t].groupY][groups[t].groupX] != FIELD_FREE)
                    {
                        int foodId = field[groups[t].groupY][groups[t].groupX];
                        if((foodAmount(foodId) <= 0) || ((groups[t].size > 1) && (foodAmount(foodId) < FOOD_AMOUNT_TOOSMALL)))
                        {
                            groups[t].status = STATUS_WANDERING;
                        } else
                        {
                            if((groups[t].size > 1) && (foods[foodId].amount <= 0)) error("can't butcher an empty source");
                            // butcher the food and pack up
                            butcherFood(t, field[groups[t].groupY][groups[t].groupX]);
                            groups[t].status = (foods[foodId].type == FOOD_BERRY) ? STATUS_RETURNING_BERRY : STATUS_RETURNING_MEAT;
                        }
                    } else
                    {
                        // no food here, start looking around
                        groups[t].status = STATUS_WANDERING;
                    }
                    if(((groups[t].status == STATUS_FETCHING) || (groups[t].status == STATUS_WANDERING)) && isTimeToReturn(t))
                    {
                        // can't find the food, give up
                        groups[t].status = STATUS_GIVINGUP;
                    }
                    // decrease energy for all members
                    groupStepMembers(t);
                    break;
                }
                case STATUS_WANDERING:
                {
                    if(field[groups[t].groupY][groups[t].groupX] != FIELD_FREE)
                    {
                        int foodId = field[groups[t].groupY][groups[t].groupX];
                        if(foodAmount(foodId) > 0)
                        {
                            // butcher the food and pack up
                            butcherFood(t, foodId);
                            if(groups[t].maxLoad > 0)
                                groups[t].status = (foods[foodId].type == FOOD_BERRY) ? STATUS_RETURNING_BERRY : STATUS_RETURNING_MEAT;
                        }
                    }
                    if((groups[t].status == STATUS_WANDERING) && isTimeToReturn(t))
                    {
                        // can't find the food, give up
                        groups[t].status = STATUS_GIVINGUP;
                    } else
                    {
                        // move randomly looking for the food in the area
                        int dx = 0, dy = 0;
                        switch(randomWalk())
                        {
                            case 0: dx = 0; dy = -1; break;
                            case 1: dx = 1; dy = 0; break;
                            case 2: dx = 0; dy = 1; break;
                            case 3: dx = -1; dy = 0; break;
                        }
                        groups[t].groupX = bound(groups[t].groupX + dx, 0, FIELD_SIZE-1);
                        groups[t].groupY = bound(groups[t].groupY + dy, 0, FIELD_SIZE-1);
                    }
                    // decrease energy for all members
                    groupStepMembers(t);
                    break;
                }
                case STATUS_RETURNING_BERRY:
                case STATUS_RETURNING_MEAT:
                {
                    // return to camp
                    if((step % LOADSKIP_SCALE) >= groups[t].loadSkip)
                    {
                        if(groups[t].groupX > campX)
                            groups[t].groupX--;
                        else if(groups[t].groupX < campX)
                            groups[t].groupX++;
                        else if(groups[t].groupY > campY)
                            groups[t].groupY--;
                        else if(groups[t].groupY < campY)
                            groups[t].groupY++;
                        else
                        {
                            updateStepStats(t);
                            groups[t].status = STATUS_RETURNED;
                        }
                    } else
                    {
                    }
                    // decrease energy for all members
                    groupStepMembers(t);
                    break;
                }
                case STATUS_GIVINGUP:
                {
                    // return to camp
                    if(groups[t].groupX > campX)
                        groups[t].groupX--;
                    else if(groups[t].groupX < campX)
                        groups[t].groupX++;
                    else if(groups[t].groupY > campY)
                        groups[t].groupY--;
                    else if(groups[t].groupY < campY)
                        groups[t].groupY++;
                    else
                    {
                        updateStepStats(t);
                        groups[t].status = STATUS_IDLE;
                    }
                    // decrease energy for all members
                    groupStepMembers(t);
                    break;
                }
            }
        }
    }
}

void shareAndEatFood()
{
    // share and eat food
    int sumfood = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
    {
        individuals[t].foodShare = 0;
        if(individuals[t].status == STATUS_FREE) continue;
        if(individuals[t].status == STATUS_CHILD)
        {
            individuals[t].energy -= FOOD_CHILD_IDLE;
            individuals[t].energy -= individuals[t].traitCommunication * COMMUNICATION_COST_CHILD_PERCENT;
        }else
        {
            sumfood += individuals[t].foodLoad;
            //printf("individual %d gathered %d\n", t, individuals[t].foodLoad);
            individuals[t].energy -= FOOD_IDLE;
            individuals[t].energy -= individuals[t].traitCommunication * COMMUNICATION_COST_PERCENT;
        }
        if(individuals[t].energy <= 0)
        {
            deadByHunger++;
            if(individuals[t].status == STATUS_CHILD)
                childrenDeadByHunger++;
            individualFree(t);
        }
    }
    //printf("day %d sumfood=%d\n", day, sumfood);
    for(int t = 0; t < GROUP_NUM_MAX; t++)
    {
        switch(groups[t].status)
        {
            case STATUS_SEARCHING:
            case STATUS_FETCHING:
            case STATUS_FOUND:
            case STATUS_GIVINGUP:
            case STATUS_WANDERING:
            case STATUS_RETURNING_BERRY:
            case STATUS_RETURNING_MEAT:
                if(distance(campX, campY, groups[t].groupX, groups[t].groupY) > 1)
                    error("group outside camp at dusk");
            case STATUS_IDLE:
                groupFree(t);
                break;
            case STATUS_RETURNED:
                shareFood(t);
                groupFree(t);
                break;
            case STATUS_STORYTIME:
                shareFood(t);
                break;
            case STATUS_FREE:
                break;
            default:
                error("invalid group status!");
        }
    }
    for(int g = 0; g < GROUP_NUM_MAX; g++)
        if((groups[g].status != STATUS_FREE) && (groups[g].status != STATUS_STORYTIME))
        {
            error("group is still active");
        }
    // check rations for surplus food
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
    {
        if(individuals[t].status == STATUS_FREE) continue;
        if(individuals[t].foodShare > CHILD_BIRTH_SPARE)
        {
            individuals[t].foodShare -= CHILD_BIRTH_SPARE;
            individuals[t].childBirthEnergy += CHILD_BIRTH_SPARE;
        }
        if(individuals[t].foodShare > (FOOD_EATEN_MAX * 2))
        {
            spareFood += individuals[t].foodShare - (FOOD_EATEN_MAX * 2);
            individuals[t].foodShare = FOOD_EATEN_MAX * 2;
            actualEatenHome += individuals[t].foodShare;
        }
    }
    // feed the kids
    struct CommsTable children[INDIVIDUALS_NUM];
    int childrenNum = 0;
    childrenStarving = 0;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
        if(individuals[t].status == STATUS_CHILD)
        {
            children[childrenNum].id = t;
            children[childrenNum++].result = day - individuals[t].birthDay;
        }
    if(childrenNum > 0)
    {
        qsort(children, childrenNum, sizeof(struct CommsTable), compareCommsTableResult);
        for(int t = 0; t < childrenNum; t++)
        {
            int childId = children[t].id;
            int needs = minInt(FOOD_EATEN_MAX, spareFood);
            if(spareFood > 0)
            {
                individuals[childId].foodShare += needs;
                spareFood -= needs;
            }else
            {
                childrenStarving++;
            }
        }
    }
    motivationPercent = bound(motivationPercent / 2 + ((childrenNum == 0) ? 0 : ((100 * childrenStarving) / childrenNum)), 0, 100);
    // divide suprlus food
    if(spareFood > 0)
    {
        int shareCount = 0;
        int sharedFood;
        for(int t = 0; t < INDIVIDUALS_NUM; t++)
        {
            if((individuals[t].status == STATUS_FREE) || (individuals[t].status == STATUS_CHILD) || (individuals[t].energy >= ENERGY_MAX) || (individuals[t].foodShare >= (FOOD_EATEN_MAX * 2))) continue;
            shareCount++;
        }
        sharedFood = minInt(spareFood / shareCount, FOOD_EATEN_MAX);
        for(int t = 0; t < INDIVIDUALS_NUM; t++)
        {
            if((individuals[t].status == STATUS_FREE) || (individuals[t].status == STATUS_CHILD) || (individuals[t].energy >= ENERGY_MAX) || (individuals[t].foodShare >= (FOOD_EATEN_MAX * 2))) continue;
            int foodShare = minInt(individuals[t].foodShare + sharedFood, FOOD_EATEN_MAX * 2);
            individuals[t].foodShare = foodShare;
            actualEatenShared += foodShare;
        }
    }
    // actual eating
    //int dayOfTheSum = day % AVG_DAYS;
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
    {
        if(individuals[t].status == STATUS_FREE) continue;
        if(individuals[t].foodShare >= FOOD_EATEN_MAX * 2)
            individuals[t].foodShare = FOOD_EATEN_MAX * 2;
        individuals[t].energy += individuals[t].foodShare;
        if(individuals[t].status == STATUS_CHILD)
        {
            if(individuals[t].energy > CHILD_ENERGY_MAX)
                individuals[t].energy = CHILD_ENERGY_MAX;
        } else
        {
            actualEatenKids += individuals[t].foodShare;
            if(individuals[t].energy > ENERGY_MAX)
                individuals[t].energy = ENERGY_MAX;
        }
        //ndividuals[t].previousEnergySum -= individuals[t].previousEnergy[dayOfTheSum];
        //individuals[t].previousEnergy[dayOfTheSum] = individuals[t].energy;
        //individuals[t].previousEnergySum += individuals[t].energy;
        //printf("sum = %d\n", individuals[t].previousEnergySum);
    }
}

void tellStories()
{
    // tell stories about food
    struct CommsTable groupOrder[GROUP_NUM_MAX_LIMIT];
    int groupOrderCnt = 0;
    for(int t = 0; t < GROUP_NUM_MAX; t++)
    {
        switch(groups[t].status)
        {
            case STATUS_STORYTIME:
                if(groups[t].members[0] == INGROUP_NONE)
                {
                    groupFree(t);
                    break;
                }
                groupOrder[groupOrderCnt].id = t;
                groupOrder[groupOrderCnt].value = individuals[groups[t].members[0]].traitCommunication;
                groupOrderCnt++;
                break;
        }
    }
    qsort(groupOrder, groupOrderCnt, sizeof(struct CommsTable), compareCommsTableValue);
    for(int t = 0; t < groupOrderCnt; t++)
    {
        int id = groupOrder[t].id;
        communicate(id);
        if(groups[id].size <= 1)
            groupFree(id);
    }
 }

 void updateIndividuals()
 {
    if(loggingIndividual) logIndividualStart(day);
    // select braves
    for(int t = 0; t < INDIVIDUALS_NUM; t++)
    {
        if(individuals[t].status == STATUS_FREE) continue;
        if(individuals[t].energy <= 0)
        {
            deadByHunger++;
            if(individuals[t].status == STATUS_CHILD)
                childrenDeadByHunger++;
            individualFree(t);
        } else if(randl(NATURAL_DEATH) == 0)
        {
            individualFree(t);
            deadByNatural++;
        } else if((day - individuals[t].birthDay) > AGE_MAX)
        {
            individualFree(t);
            deadByMaxAge++;
        } else if((childrenDone == 0) && (individuals[t].status != STATUS_CHILD) && (individuals[t].childBirthEnergy > CHILD_BIRTH_ENERGY))
        {
            if(addNewChildWithParent(t))
                childrenPerDay++;
            else
                childrenDone = 1;
        }
        if((individuals[t].status == STATUS_CHILD) && ((day - individuals[t].birthDay) >= AGE_ADULT))
        {
            individuals[t].status = STATUS_IDLE;
            adultsPerDay++;
            if(numberOfAdults() >= AdultsNum)
            {
                // leave the tribe due to overpopulation
                youngAdultsLeft++;
                individualFree(t);
            }
        }
        if((individuals[t].status == STATUS_IDLE) && (individuals[t].inGroup == INGROUP_NONE))
        {
            int bravery = calcBravery(individuals[t].energy);
            if(randl(100) < bravery) // create a new scout
            {
                int g = groupAlloc(t);
                if(g != INGROUP_NONE)
                {
                } else
                {
                    error("out of group slots...");
                }
            }
        }
        if(loggingIndividual)
            if(individuals[t].status != STATUS_FREE)
                logIndividual(individuals[t].energy, individuals[t].traitCommunication);
    }
    if(loggingIndividual) logIndividualEnd();
 }

 void doLogging()
 {
    if(loggingSum)
    {
        int numPeople;
        int adults;
        int children;
        int sumEnergy = sumOfEnergy();
        double sumCommunication, minCom, maxCom;
        int avgFoodDistance, avgFoodAmount;
        int meatsEaten, berriesEaten;
        int sumAge, sumAgeKids;
        int oldest;
        int statResting, statScouting, statFetching;
        int berrySum, berryCnt, meatSum, meatCnt;
        int foodNeeded;
        float avgGroupsize = averageGroupsize();
        sumOfAge(&sumAge, &sumAgeKids);
        census(&numPeople, &adults, &children, &oldest);
        sumOfCommunication(&sumCommunication, &minCom, &maxCom);
        updateFoodStatsEnd();
        getFoodStats(&avgFoodDistance, &avgFoodAmount, &meatsEaten, &berriesEaten, &berrySum, &berryCnt, &meatSum, &meatCnt, &foodNeeded);
        updateActivityStats(&statResting, &statScouting, &statFetching);
        if(numPeople == 0)
        {
            logGlobal(day,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,-1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,-1,0,0);
        }else
        {
            float avgAgeAdults = 0;
            float avgAgeKids = 0;
            float groupFillPercent = -1;
            float groupFillRelative = -1;
            float freeTimeAvg = 0;
            if(adults > 0) avgAgeAdults = (float)sumAge / adults;
            if(children > 0) avgAgeKids = (float)sumAgeKids / children;
            if(groupFillCnt > 0)
            {
              groupFillPercent = (float)groupFillPercentSum / (float)groupFillCnt;
              groupFillRelative = (float)groupFillRelativeSum / (float)groupFillCnt;
            }
            if(day < MEAT_START_DAY)
                if((groupFillPercent > 0) || (groupFillPercentMax > 0) || (groupFillRelative > 0) || (groupFillRelativeMax > 0))
                    error("group error");
            if(stepsTakenAll == 0)
            {
                if(foodBroughtinAll != 0) error("nobody moved this day but food was brought in?");
                stepsTakenAll = -1;
                foodBroughtinAll = -1;
            }
            if(freeTimeCnt > 0)
                freeTimeAvg = ((float)freeTime) / ((float)freeTimeCnt);
            logGlobal(day, numPeople,
                  sumEnergy, ((float)sumEnergy)/((float)numPeople),
                  sumCommunication, ((float)sumCommunication)/((float)numPeople),
                  spareFood,
                  avgFoodDistance, avgFoodAmount, meatsEaten, berriesEaten,
                  newChildren, deadByNatural, deadByHunger, deadByPredation, avgAgeAdults,
                  minCom, maxCom, avgGroupsize, adults, children, avgAgeKids, oldest,
                  youngAdultsLeft, groupFillPercent, groupFillPercentMax, groupFillRelative, groupFillRelativeMax,
                  statResting, statScouting, statFetching, berrySum, berryCnt, meatSum, meatCnt,
                  childrenStarving, foodNeeded, actualEatenWorking, actualEatenHome, actualEatenShared, actualEatenKids, deadByMaxAge,
                  stepsTakenAll, foodBroughtinAll, movingAdults, childrenDeadByHunger, freeTimeAvg);
        }
    }
}

void stepDayEnd()
{
    shareAndEatFood();
    tellStories();
    updateIndividuals();
    doLogging();
}

void parseIntParam(int argc, char **argv, int id, int vmin, int vmax, int *variable)
{
    if(argc <= id) return;
    sscanf(argv[id], "%d", variable);
    if(*variable < vmin) *variable = vmin;
    if(*variable > vmax) *variable = vmax;
}

void parseFloatParam(int argc, char **argv, int id, float vmin, float vmax, float *variable)
{
    if(argc <= id) return;
    sscanf(argv[id], "%f", variable);
    if(*variable < vmin) *variable = vmin;
    if(*variable > vmax) *variable = vmax;
}

int main(int argc, char **argv)
{
    parseIntParam(argc, argv, 1, 0, 0xfffffff, &RndSeed);
    parseIntParam(argc, argv, 2, 1, FOODS_NUM_LIMIT/2, &FoodsBerryNum);
    parseIntParam(argc, argv, 3, 1, FOODS_NUM_LIMIT/2, &FoodsMeatNum);
    parseIntParam(argc, argv, 4, 1, INDIVIDUALS_NUM/2, &AdultsNum);
    MeatSizeLow = ((MEAT_TOTAL_ENERGY / FoodsMeatNum) * 60) / 75;
    MeatSizeHigh = ((MEAT_TOTAL_ENERGY / FoodsMeatNum) * 90) / 75;
    parseFloatParam(argc, argv, 5, 0, MUTATION_RATE_LIMIT, &MutationRate);
    parseIntParam(argc, argv, 6, 0, 100000, &TransientYears);
    parseIntParam(argc, argv, 7, 1, 200000, &MeatSizeLow);
    parseIntParam(argc, argv, 8, 1, 200000, &MeatSizeHigh);
    if(MeatSizeLow > MeatSizeHigh) error("MeatSizeLow must be less or equal to MeatSizeHigh");
    if(RndSeed == 0) RndSeed = time(NULL);
    printf("RndSeed=%d FoodsBerryNum=%d FoodsMeatNum=%d AdultsNum=%d MutationRate=%f TransientYears=%d MeatSizeLow=%d MeatSizeHigh=%d\n", RndSeed, FoodsBerryNum, FoodsMeatNum, AdultsNum, MutationRate, TransientYears, MeatSizeLow, MeatSizeHigh);
    seed(RndSeed);
    init();
    updateFoodStatsBegin();
    if(loggingIndividual || loggingSum)
    {
        char id[256];
        snprintf(id, sizeof(id), "%d.%d.%d.%d.%f.%d.%d.%d", RndSeed, FoodsBerryNum, FoodsMeatNum, AdultsNum, MutationRate, TransientYears, MeatSizeLow, MeatSizeHigh);
        logInit(loggingIndividual, loggingSum, ((argc < 2) ? NULL : id));
        logGlobalParams(AVG_DAYS, gitversion, RndSeed, INDIVIDUALS_NUM, FoodsBerryNum, FoodsMeatNum, FOOD_LEADER_MAX, GROUP_SIZE, GROUP_NUM_MAX, TransientYears, MeatSizeLow, MeatSizeHigh);
    }
    for(day = SIM_START_DAY; (day < DAYS_NUM) && (numberOfPeople() != 0); day++)
    {
        stepDayBegin();
        stepDayMovement();
        stepDayEnd();
    }
    if(loggingIndividual || loggingSum)
    {
        logSaveTblstats();
        logDone();
    }
    return(0);
}
