#include <stdlib.h>
#include <stdio.h>
#include "log.h"

FILE *logFileIndividualEnergy = NULL;
FILE *logFileIndividualCommunication = NULL;
FILE *logFileGlobal = NULL;
FILE *logFileTraitGroups = NULL;
FILE *logFileAgeGroups = NULL;
FILE *logFileTblStatsCnt = NULL;
FILE *logFileTblStatsSum = NULL;
int logGlobalAvgDays = 1;
int logGlobalCntDays = 0;
#define BUFCNT (48)
double logGlobalBuf[BUFCNT];
int logGlobalGroupFillPercentCnt = 0;
int logGlobalAvgGroupsizeCnt = 0;
int logStepsTakenCnt = 0;
int logTblStatTable[11][5][2] = {};

int logInit(int individual, int sum, const char *id)
{
    char fileName[256];
    if(sum)
    {
        if(id != NULL) snprintf(fileName, sizeof(fileName), "results.%s.txt", id); else snprintf(fileName, sizeof(fileName), "results.txt");
        if((logFileGlobal = fopen(fileName, "wt")) == NULL) return(-1);
        if(id != NULL) snprintf(fileName, sizeof(fileName), "traitgroups.%s.txt", id); else snprintf(fileName, sizeof(fileName), "traitgroups.txt");
        if((logFileTraitGroups = fopen(fileName, "wt")) == NULL) return(-1);
        if(id != NULL) snprintf(fileName, sizeof(fileName), "agegroups.%s.txt", id); else snprintf(fileName, sizeof(fileName), "agegroups.txt");
        if((logFileAgeGroups = fopen(fileName, "wt")) == NULL) return(-1);
        if(id != NULL) snprintf(fileName, sizeof(fileName), "tblstatscnt.%s.txt", id); else snprintf(fileName, sizeof(fileName), "tblstatscnt.txt");
        if((logFileTblStatsCnt = fopen(fileName, "wt")) == NULL) return(-1);
        if(id != NULL) snprintf(fileName, sizeof(fileName), "tblstatssum.%s.txt", id); else snprintf(fileName, sizeof(fileName), "tblstatssum.txt");
        if((logFileTblStatsSum = fopen(fileName, "wt")) == NULL) return(-1);
    }
    if(individual)
    {
        if(id != NULL) snprintf(fileName, sizeof(fileName), "result_energies.%s.txt", id); else snprintf(fileName, sizeof(fileName), "result_energies.txt");
        if((logFileIndividualEnergy = fopen(fileName, "wt")) == NULL) return(-1);
        if(id != NULL) snprintf(fileName, sizeof(fileName), "result_communications.%s.txt", id); else snprintf(fileName, sizeof(fileName), "result_communications.txt");
        if((logFileIndividualCommunication = fopen("result_communications.txt", "wt")) == NULL) return(-1);
    }
    return(0);
}

int logIndividualStart(int dayStep)
{
    int r = 0;
    if(fprintf(logFileIndividualEnergy, "%d, ", dayStep) != 1) r = -1;
    if(fprintf(logFileIndividualCommunication, "%d, ", dayStep) != 1) r = -1;
    return(r);
}

int logIndividualEnd()
{
    int r = 0;
    if(fprintf(logFileIndividualEnergy, "\n") != 1) r = -1;
    if(fprintf(logFileIndividualCommunication, "\n") != 1) r = -1;
    return(r);
}

void logDone()
{
    if(logFileGlobal != NULL)
    {
        fclose(logFileGlobal);
        logFileGlobal = NULL;
    }
    if(logFileIndividualEnergy != NULL)
    {
        fclose(logFileIndividualEnergy);
        logFileIndividualEnergy = NULL;
    }
    if(logFileIndividualCommunication != NULL)
    {
        fclose(logFileIndividualCommunication);
        logFileIndividualCommunication = NULL;
    }
    if(logFileTraitGroups != NULL)
    {
        fclose(logFileTraitGroups);
        logFileTraitGroups = NULL;
    }
    if(logFileTblStatsCnt != NULL)
    {
        fclose(logFileTblStatsCnt);
        logFileTblStatsCnt = NULL;
    }
    if(logFileTblStatsSum != NULL)
    {
        fclose(logFileTblStatsSum);
        logFileTblStatsSum = NULL;
    }
}

int logGlobalParams(int avgDays, const char* version, int seed, int individualNum, int foodBerryNum, int foodMeatNum, int foodLeader, int groupCount, int groupSize, int transientYears, int meatSizeLow, int meatSizeHigh)
{
    logGlobalAvgDays = avgDays;
    logGlobalCntDays = 0;
    for(int t = 0; t < BUFCNT; t++)
        logGlobalBuf[t] = 0;
    if(fprintf(logFileGlobal, "# githash=%s randomSeed=%d\n", version, seed) <= 0) return(-1);
    if(fprintf(logFileGlobal, "# individualNum=%d, foodBerryNum=%d foodMeatNum=%d foodLeader=%d groupCount=%d groupSize=%d transientYears=%d MeatSizeLow=%d MeatSizeHigh=%d\n", individualNum, foodBerryNum, foodMeatNum, foodLeader, groupCount, groupSize, transientYears, meatSizeLow, meatSizeHigh) <= 0) return(-1);
    if(fprintf(logFileGlobal, "# day individuals energySum energyAvg traitCommunicationSum traitCommunicationAvg spareFood avgFoodDistance avgFoodAmount meatsEaten berriesEaten berryPercent newChildren deadByNatural deadByHunger deadByPredation avgAge minCommunication maxCommunication avgGroupsize adultsNum childrenNum avgAgeChildren oldest youngAdultsLeft groupFillPercent groupFillMax relativeFillPercent relativeFillMax resting scouting fetching berrySum berryCnt meatSum meatCnt childrenStarving foodNeeded actualEatenWork actualEatenHome actualEatenShared actualEatenKids deadByMaxAge stepsTaken foodBroughtin movingAduts childrenDeadByHunger freeTimeAvg\n") <= 0) return(-1);
    return(0);
}

int logGlobal(int dayStep, int individualNum, int energySum, float energyAvg, double traitCommunicationSum, float traitCommunicationAvg, int spareFood, int avgFoodDistance, int avgFoodAmount, int meatsEaten, int berriesEaten, int newChildren, int deadByNatural, int deadByHunger, int deadByPredation, float avgAge, double minCommunication, double maxCommunication, float avgGroupsize, int adultsNum, int childrenNum, float avgAgeChildren, int oldest, int youngAdultsLeft, float groupFillPercent, float groupFillMax, float relativeFillPercent, float relativeFillMax, int resting, int scouting, int fetching, int berrySum, int berryCnt, int meatSum, int meatCnt, int childrenStarving, int foodNeeded, int actualEatenWork, int actualEatenHome, int actualEatenShared, int actualEatenKids, int deadByMaxAge, int stepsTaken, int foodBroughtin, int movingAdults, int childrenDeadByHunger, double freeTime)
{
    logGlobalBuf[0] += dayStep;
    logGlobalBuf[1] += individualNum;
    logGlobalBuf[2] += energySum;
    logGlobalBuf[3] += energyAvg;
    logGlobalBuf[4] += traitCommunicationSum;
    logGlobalBuf[5] += traitCommunicationAvg;
    logGlobalBuf[6] += spareFood;
    logGlobalBuf[7] += avgFoodDistance;
    logGlobalBuf[8] += avgFoodAmount;
    logGlobalBuf[9] += meatsEaten;
    logGlobalBuf[10] += berriesEaten;
    logGlobalBuf[11] += -1; // TODO!!!
    logGlobalBuf[12] += newChildren;
    logGlobalBuf[13] += deadByNatural;
    logGlobalBuf[14] += deadByHunger;
    logGlobalBuf[15] += deadByPredation;
    logGlobalBuf[16] += avgAge;
    logGlobalBuf[17] += minCommunication;
    logGlobalBuf[18] += maxCommunication;
    if(avgGroupsize > 0)
    {
        logGlobalBuf[19] += avgGroupsize;
        logGlobalAvgGroupsizeCnt++;
    }
    logGlobalBuf[20] += adultsNum;
    logGlobalBuf[21] += childrenNum;
    logGlobalBuf[22] += avgAgeChildren;
    logGlobalBuf[23] += oldest;
    logGlobalBuf[24] += youngAdultsLeft;
    if(groupFillPercent >= 0)
    {
        logGlobalBuf[25] += groupFillPercent;
        logGlobalBuf[26] += groupFillMax;
        logGlobalBuf[27] += relativeFillPercent;
        logGlobalBuf[28] += relativeFillMax;
        logGlobalGroupFillPercentCnt ++;
    }
    logGlobalBuf[29] += resting;
    logGlobalBuf[30] += scouting;
    logGlobalBuf[31] += fetching;
    logGlobalBuf[32] += berrySum;
    logGlobalBuf[33] += berryCnt;
    logGlobalBuf[34] += meatSum;
    logGlobalBuf[35] += meatCnt;
    logGlobalBuf[36] += childrenStarving;
    logGlobalBuf[37] += foodNeeded;
    logGlobalBuf[38] += actualEatenWork;
    logGlobalBuf[39] += actualEatenHome;
    logGlobalBuf[40] += actualEatenShared;
    logGlobalBuf[41] += actualEatenKids;
    logGlobalBuf[42] += deadByMaxAge;
    if(stepsTaken >= 0)
    {
        logGlobalBuf[43] += stepsTaken;
        logGlobalBuf[44] += foodBroughtin;
        logGlobalBuf[45] += movingAdults;
        logStepsTakenCnt++;
    }
    logGlobalBuf[46] += childrenDeadByHunger;
    logGlobalBuf[47] += freeTime;
    if(++logGlobalCntDays == logGlobalAvgDays)
    {
        logGlobalCntDays = 0;
        for(int t = 0; t < BUFCNT; t++)
        {
            if(t == 19)
            {
                if(logGlobalAvgGroupsizeCnt > 0)
                    fprintf(logFileGlobal, "%f ", logGlobalBuf[t] / ((float)logGlobalAvgGroupsizeCnt));
                else
                    fprintf(logFileGlobal, "? ");
            } else if((t >= 25) && (t <= 28))
            {
                if(logGlobalGroupFillPercentCnt > 0)
                    fprintf(logFileGlobal, "%f ", logGlobalBuf[t] / ((float)logGlobalGroupFillPercentCnt));
                else
                    fprintf(logFileGlobal, "? ");
            } else if((t >= 43) && (t <= 45))
            {
                if(logStepsTakenCnt > 0)
                    fprintf(logFileGlobal, "%f ", logGlobalBuf[t] / ((float)logStepsTakenCnt));
                else
                    fprintf(logFileGlobal, "? ");
            } else
            {
                fprintf(logFileGlobal, "%f ", logGlobalBuf[t] / ((float)logGlobalAvgDays));
            }
            logGlobalBuf[t] = 0.0;
        }
        logGlobalGroupFillPercentCnt = 0;
        logGlobalAvgGroupsizeCnt = 0;
        logStepsTakenCnt = 0;
        fprintf(logFileGlobal, "\n");
    }
    return(0);
}

int logIndividual(int energy, double communication)
{
    int r = 0;
    if(fprintf(logFileIndividualEnergy, "%d, ", energy) <= 0) r = -1;
    if(fprintf(logFileIndividualCommunication, "%lf, ", communication) <= 0) r = -1;
    return(r);
}


int logTraitHistogram(int day, int *traitGroups, int groupCount)
{
    int r = 0;
    if(fprintf(logFileTraitGroups, "%d   ", day) <= 0) r = -1;
    for(int t = 0; t < groupCount; t++)
        if(fprintf(logFileTraitGroups, "%d ", traitGroups[t]) <= 0) r = -1;
    if(fprintf(logFileTraitGroups, "\n") <= 0) r = -1;
    return(r);
}

int logAgeHistogram(int day, int *ageGroups, int groupCount)
{
    int r = 0;
    if(fprintf(logFileAgeGroups, "%d    ", day) <= 0) r = -1;
    for(int t = 0; t < groupCount; t++)
        if(fprintf(logFileAgeGroups, "%d ", ageGroups[t]) <= 0) r = -1;
    if(fprintf(logFileAgeGroups, "\n") <= 0) r = -1;
    return(r);
}

int logTblStats(int amount, int distance, int people)
{
    if((amount < 0) || (amount >= 11) || (distance < 0) || (distance >= 5)) return(-1);
    logTblStatTable[amount][distance][0]++;
    logTblStatTable[amount][distance][1] += people;
    return(0);
}

int logSaveTblstats()
{
    int r = 0;
    for(int amount = 0; amount < 11; amount++)
    {
        for(int distance = 0; distance < 5; distance++)
        {
            if(fprintf(logFileTblStatsCnt, "%d ", logTblStatTable[amount][distance][0]) <= 0) r = -1;
            if(fprintf(logFileTblStatsSum, "%d ", logTblStatTable[amount][distance][1]) <= 0) r = -1;
        }
        if(fprintf(logFileTblStatsCnt, "\n") <= 0) r = -1;
        if(fprintf(logFileTblStatsSum, "\n") <= 0) r = -1;
    }
    return(r);
}
