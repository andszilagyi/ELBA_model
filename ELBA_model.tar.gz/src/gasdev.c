#include <math.h>
#include "rand.h"
#include "gasdev.h"

/* (C) Copr. 1986-92 Numerical Recipes Software *(5$r. */

float gasdev_rand()
{
	static int iset=0;
	static float gset;
	float fac,rsq,v1,v2;

	if  (iset == 0) {
		do {
			v1=2.0*randd()-1.0;
			v2=2.0*randd()-1.0;
			rsq=v1*v1+v2*v2;
		} while (rsq >= 1.0 || rsq == 0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=v1*fac;
		iset=1;
		return v2*fac;
	} else {
		iset=0;
		return gset;
	}
}

double gasdev_scaled(double scale)
{
	return(gasdev_rand() * scale);
}
