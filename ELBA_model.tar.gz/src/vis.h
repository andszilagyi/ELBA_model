#ifndef VIS_H
#define VIS_H

void visInit(int w, int h);
void visClear();
int visSave(const char *fileName, int day, int step);
void visPathSet(int x, int y);
void visHomeSet(int x, int y);
void visFoodSet(int x, int y, int amount, int type);
void visUnitSet(int x, int y, int mode);

int aniInit(int dayFrom, int dayTo);
int aniDone();
int aniNewDay(int day);
int aniNewStep(int step);
int aniEndStep();
int aniBush(int x, int y, int level);
int aniMeat(int x, int y, int level);
int aniMoveGroup(int fromX, int fromY, int toX, int toY, const char *state, int size);
int aniFoundMeat(int x, int y, int amount);
int aniButcherMeat(int x, int y, int amount);
int aniGivingUp(int x, int y);
int aniTooDecayed(int x, int y);
int aniIsAGoodDay();

#endif // VIS_H
