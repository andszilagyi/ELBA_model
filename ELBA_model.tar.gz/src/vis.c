#include "vis.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

int visWidth = 0;
int visHeight = 0;

int *visPathMem = NULL;
uint8_t *visBuffer = NULL;

void visInit(int w, int h)
{
    visPathMem = calloc(w * h, sizeof(int));
    visBuffer = calloc(w * h * 3, sizeof(uint8_t));
    visWidth = w;
    visHeight = h;
    visClear();
}

void visClear()
{
    for(int t = 0; t < visWidth * visHeight; t++)
    {
        visBuffer[t*3] = 0;
        visBuffer[t*3+1] = 255;
        visBuffer[t*3+2] = 0;
    }
    //for(int t = 0; t < visWidth * visHeight; t++)
    //    visPathMem[t] = 0;
}

int visFade(int from, int to, int alpha)
{
  return((
          (from * (255 - alpha)) + (to * alpha)
         ) / 255);
}

int visSave(const char *fileName, int day, int step)
{
    FILE* f = fopen(fileName, "wb");
    if(f == NULL) return(-1);
    fprintf(f, "P6\n# %d %d\n%d %d\n255\n", day, step, visWidth, visHeight);
    for(int t = 0; t < visWidth * visHeight; t++)
    {
        if((visPathMem[t] > 0) && (visBuffer[t*3] == 0) && (visBuffer[t*3+1] == 255) && (visBuffer[t*3+2] == 0))
        {
            int a = (visPathMem[t] / 10);
            if(a > 255) a = 255;
            visBuffer[t*3] = visFade(0, 255, a);
            visBuffer[t*3+1] = visFade(255, 248, a);
            visBuffer[t*3+2] = visFade(0, 220, a);
        }
    }
    if(fwrite(visBuffer, visWidth * visHeight * 3, 1, f) != 1)
    {
        fclose(f);
        return(-1);
    }
    fclose(f);
    return(0);
}

void visPathSet(int x, int y)
{
    if((x < 0) || (y < 0) || (x >= visWidth) || (y > visHeight)) return;
    visPathMem[x + y * visWidth]++;
}

void visHomeSet(int x, int y)
{
    int t;
    if((x < 0) || (y < 0) || (x >= visWidth) || (y > visHeight)) return;
    t = (x + y * visWidth) * 3;
    visBuffer[t] = 0;
    visBuffer[t+1] = 254;
    visBuffer[t+2] = 0;
}

void visFoodSet(int x, int y, int amount, int type)
{
    int t, v;
    if((x < 0) || (y < 0) || (x >= visWidth) || (y > visHeight)) return;
    t = (x + y * visWidth) * 3;
    v = 155+amount;
    if(v > 255) v = 255;
    if(type == 0)
    {
        visBuffer[t] = 0;
        visBuffer[t+1] = 0;
        visBuffer[t+2] = v;
    }else
    {
        visBuffer[t] = v;
        visBuffer[t+1] = 0;
        visBuffer[t+2] = 0;
    }
}

static int visUnitColors[][3] =
{
    {0,0,255},
    {0,0,127},
    {255,0,255},
    {0,0,0},
    {131,80,46}
};

void visUnitSet(int x, int y, int mode)
{
    int t;
    if((x < 0) || (y < 0) || (x >= visWidth) || (y > visHeight)) return;
    t = (x + y * visWidth) * 3;
    visBuffer[t] = visUnitColors[mode % 5][0];
    visBuffer[t+1] = visUnitColors[mode % 5][1];
    visBuffer[t+2] = visUnitColors[mode % 5][2];
    visPathSet(x, y);
}

FILE *aniFile = NULL;
int aniDayFrom = -1;
int aniDayTo = -1;
int aniDay = -1;
int aniStep = -1;

int aniInit(int dayFrom, int dayTo)
{
    char fn[256];
    aniDayFrom = dayFrom;
    aniDayTo = dayTo;
    snprintf(fn, sizeof(fn), "ani_%d_%d.txt", dayFrom, dayTo);
    if((aniFile = fopen(fn, "wt")) == NULL)
        return(-1);
    return(fprintf(aniFile, "# animation saved from day %d to day %d\n", dayFrom, dayTo));
}

int aniDone()
{
    if(aniFile != NULL)
    {
        fprintf(aniFile, "# eof\n");
        fclose(aniFile);
        aniFile = NULL;
    }
    return(0);
}

int aniNewDay(int day)
{
    aniDay = day;
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "# -------- 8< --------\nnewday %d\n", aniDay));
}

int aniNewStep(int step)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    aniStep = step;
    return(fprintf(aniFile, "newstep %d %d\n", aniDay, aniStep));
}

int aniEndStep()
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "endstep %d %d\n", aniDay, aniStep));
}

int aniBush(int x, int y, int level)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "bush %d %d %d\n", x, y, level));
}

int aniMeat(int x, int y, int level)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "meat %d %d %d\n", x, y, level));
}

int aniMoveGroup(int fromX, int fromY, int toX, int toY, const char *state, int size)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "move %d %d %d %d %s %d\n", fromX, fromY, toX, toY, state, size));
}

int aniFoundMeat(int x, int y, int amount)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "foundmeat %d %d %d\n", x, y, amount));
}

int aniButcherMeat(int x, int y, int amount)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "butchermeat %d %d %d\n", x, y, amount));
}

int aniGivingUp(int x, int y)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "giveup %d %d\n", x, y));
}

int aniTooDecayed(int x, int y)
{
    if((aniDay < aniDayFrom) || (aniDay > aniDayTo))
        return(0);
    return(fprintf(aniFile, "decayedmeat %d %d\n", x, y));
}

int aniIsAGoodDay()
{
    return((aniDay >= aniDayFrom) && (aniDay <= aniDayTo));
}
